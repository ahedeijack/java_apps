/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aplicacion_4_Calcular_Numeros_Primos;

/**
 *
 * @author ahedeijack
 */
public class Main {
    public static void main (String args[]){
        
        int div = 2;
        
        System.out.println("");
        
        
    }
}


    //Calcular la canidad de numeros primeros entre un rango de numeros.
    //N de 1,000,000.00 a 1,000,100.00
    //Poner Menu Factorial con Double
    //Primo
    //Serie E
    //Pi
    //Serie E a la n
    //Elevacion 
