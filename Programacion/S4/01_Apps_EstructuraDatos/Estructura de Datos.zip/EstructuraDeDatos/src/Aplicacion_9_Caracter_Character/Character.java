/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aplicacion_9_Caracter_Character;

import java.util.Scanner;

/**
 *
 * @author ahedeijack
 */
public class Character {
    public static void main(String[] args){
        Scanner read = new Scanner(System.in);
        
        System.out.println("Ingresa tu nombre: ");
        String nombre = read.next();
        
        char c [] = new char[nombre.length()];
        
        System.out.println("Tu nombre en minusculas: ");
        
        for(int i = 0; i<nombre.length(); i++){
            System.out.println(Character.);
        }
        
        
        
    }
}
//Ingresar el nombre
//todas a minusculas
//todas a mayusculas
//vocales
//investigar el for each
