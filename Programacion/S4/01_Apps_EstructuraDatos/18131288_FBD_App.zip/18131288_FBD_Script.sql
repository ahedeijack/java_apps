create database agencia;
use agencia;

-- Creamos las tablas --
create table aerolinea(
linea  varchar(5) primary key not null,
nombreAero varchar(25)
);
alter table aerolinea change column claveAero  linea varchar(5) not null;
select * from aerolinea;
delete from aerolinea where linea = "25";
delete from aerolinea where linea = "1";
insert into aerolinea (linea,nombreAero)values("66","HOLA");
SET FOREIGN_KEY_CHECKS=0;
SET FOREIGN_KEY_CHECKS=1;


-- Nota mental 1: Crear las FK sin hacer referencia, eso se hace despúes de la creación de las tablas.

create table avion(
claveAvion varchar(5) primary key not null,
tipoAvion  varchar(25),
numPasajeros int(255),
nombreCia varchar(25)
);
-- FK ClaveAero
-- Nota mental 2: La fk debe ser igual a la pk de la tabla en relacion
alter table avion add linea varchar(5);
drop table avion;
alter table avion add foreign key (linea) references aerolinea(linea);
alter table avion add foreign key (claveVue) references vuelo(claveVue);
alter table avion drop foreign key avion_ibfk_1;
alter table avion drop claveAero;
select * from avion;
delete from avion where claveAvion = "AV01";
show create table avion;
-- 

create table vuelo(
claveVue varchar(10) primary key not null,
estadoV varchar(15),
tipoV varchar(15),
horaD varchar(10),
diaD  varchar(10),
horaO varchar(10),
diaO varchar(10)
);
-- FK ClaveVue
alter table vuelo add claveAvion varchar (5);
alter table vuelo add foreign key (claveAvion) references avion(claveAvion);
select * from vuelo;
-- xd

create table aeropuerto(
claveAero varchar(10) primary key not null,
nombAero varchar(10),
cdAero varchar(25), 
paisAero varchar(20), 
numAero int, 
colAero varchar(10), 
cpAero int(5)
);
-- fk claveVue

alter table aeropuerto add claveAvion varchar (5);
alter table aeropuerto add foreign key (claveAvion) references avion(claveAvion);
select * from aeropuerto;
-- xd

create table reservaciones(
claveRes	varchar(10) primary key not null,
horarioV varchar(10),
fechaV varchar(10),
costoRes double
);
-- fk  ClaveVue
alter table reservaciones add claveVue varchar(10);
alter table reservaciones add foreign key (claveVue) references vuelo(claveVue);
select * from reservaciones;
-- xd

create table cliente(
emailCte varchar(35) primary key not null,
contraseña varchar(20),
nombreCte varchar(25),
apPatCte varchar(25),
apMatCte varchar(25),
calleCte varchar(35),
numCte   int,
colCte   varchar(25),
cpCte	 int(5),
cdCte 	 varchar(25) 
);
-- fk ClaveRes
alter table cliente add claveRes varchar(10);
alter table cliente add foreign key (claveRes) references reservaciones(claveRes);
select * from cliente;
-- xd

create table tarjeta(
numTarjeta int (16) primary key not null, 
tipoTarj varchar(10), 
fechaVenc date, 
añoIni int(4),
nombTitular varchar(25)
);
-- fk emailCte
alter table tarjeta add emailCte varchar(35);
alter table tarjeta add foreign key (emailCte) references cliente(emailCte);
select * from tarjeta;
-- xd


-- Entidades Debiles
create table asiento(
claveVue varchar(10) primary key not null,
categoria varchar(10),
letra_numero varchar(10),
fila varchar(5),
foreign key (claveVue) references vuelo(claveVue)
);
drop table asiento;
-- fk claveVue
select * from asiento;

create table tarifa(
claveVue varchar(10) primary key not null,
costo double,
tipoC varchar(25),
impuestos double,
foreign key (claveVue) references vuelo(claveVue)
);
-- fk claveVue

create table pago(
claveRes	varchar(10) primary key not null,
tipoPago varchar(25),
fechaPago date,
cargoCosto double,
foreign key(claveRes) references reservaciones(claveRes)
);
-- fk claveRes

-- Relaciones M:N
create table avion_vuelo(
claveAvion varchar(5),
claveVue varchar(10),
primary key (claveAvion, claveVue),
foreign key (claveAvion) references avion(claveAvion),
foreign key (claveVue) references vuelo(claveVue)
);
select * from avion_vuelo;

create table vuelo_reservacion(
claveVue varchar(10),
claveRes varchar(10),
primary key (claveVue, claveRes),
foreign key (claveVue) references vuelo(claveVue),
foreign key (claveRes) references reservaciones(claveRes)
);
select * from vuelo_reservacion;

create table cliente_reservacion(
emailCte varchar(35),
claveRes varchar(10),
primary key(emailCte, claveRes),
foreign key(emailCte) references cliente(emailCte),
foreign key (claveRes) references reservaciones(claveRes)
);
select * from cliente_reservacion;

create table pago_tarjeta(
numTarjeta int (16),
primary key (numTarjeta),
foreign key (numTarjeta) references tarjeta(numTarjeta)
);
select * from pago_tarjeta;
select * from reservaciones;
select * from cliente;
-- Multivaluados
create table cliente_telefono(
emailCte varchar(35),
telCte	varchar(12),
primary key (emailCte, telCte),
foreign key (emailCte) references cliente(emailCte)
);

insert into aerolinea values (1, "Aeromexico");
insert into aerolinea values (2, "Aero-Max");
insert into aerolinea values (3, "VivaVuelos");
insert into aerolinea values (4, "Qatar Airways");
insert into aerolinea values (5, "EVA air");
insert into aerolinea values (6, "Qantas Airways");
insert into aerolinea values (7, "ANA ALL JAP");
delete from avion  where claveAero = 1;
delete from aerolinea where claveAero = 1;
select * from aerolinea;

-- Aquí va la clave de la Aerolinea
insert into avion values("AV05", "Boeing 747", 155, "VIVA AEROBUS", 1);
insert into avion values("AV38", "JET PRIVADO", 20, "AIR-EXPRESS", 2);
insert into avion values("AV48", "Boeing 747", 200, "TRIVAGO", 3);
insert into avion values("AV75", "COMERCIAL", 90, "Qatar Airlines", 4);
insert into avion values("AV01", "Boeing 747", 190, "XIN WHUN AIRS", 5);
insert into avion values("AV23", "COMERCIAL", 240, "M DE GANGAIR", 6);
insert into avion values("AV09", "JET PRIVADO", 15, "VUELOS DE MÉXICO", 7);
update avion set linea="1" where claveAvion = "AV05";
update avion set linea="2" where claveAvion = "AV38";
update avion set linea="3" where claveAvion = "AV48";
update avion set linea="4" where claveAvion = "AV75";
update avion set linea="5" where claveAvion = "AV01";
update avion set linea="6" where claveAvion = "AV23";
update avion set linea="7" where claveAvion = "AV09";
select * from avion;

truncate table vuelo;

-- Aqui va ClaveVue
insert into vuelo values("V-HK-MX-11", "En espera","Comercial","10:20","Lunes 27", "02:00","Lunes 27","AV05");
insert into vuelo values("V-CO-CN-17", "En despegue","Privado","23:30","Lunes 27", "22:21","Martes 28","AV38");
insert into vuelo values("V-CN-CH-19", "En espera","Privado","22:55","Lunes 27", "12:25","Martes 28","AV48");
insert into vuelo values("V-RU-AL-20", "En transcurso","Comercial","13:18","Martes 28", "13:55","Mier 01","AV75");
insert into vuelo values("V-AL-MX-22", "En transcurso","Privado","15:30","Martes 28", "01:29","Mier 01","AV01");
insert into vuelo values("V-MX-MX-33", "En despegue","Comercial","16:43","Martes 28", "02:18","Mier 01","AV23");
insert into vuelo values("V-CH-RU-78", "En espera","Privado","09:23","Mier 01", "20:45","Mier 01","AV09");
delete from vuelo where claveVue = "V-CH-RU-78";
select * from vuelo;
truncate table vuelo;

insert into aeropuerto values("AP-01","America", "CDMX", "Mexico", 1, "LOMAS", 39089, "AV05");
insert into aeropuerto values("AP-82","XHIN AL", "BEIJING", "CHINA", 23, "XHUAN", 79458, "AV38");
insert into aeropuerto values("AP-75","DEUSTAIRS", "BERLIN", "ALEMANIA", 5, "SAN PETTER", 98851, "AV48");
insert into aeropuerto values("AP-91","AIR CENTER", "MICHIGAN", "USS", 43, "St. Louis", 55606, "AV75");
insert into aeropuerto values("AP-33","AIRLINES", "OKLAHOMA", "USS", 78, "Roswell", 66936, "AV01");
insert into aeropuerto values("AP-46","MORPE", "MOSCU", "RUSIA", 105, "KREMLIN", 10917, "AV23");
insert into aeropuerto values("AP-48","KITTYAL", "PEKIN", "CHINA", 16, "WUHAN", 48336, "AV09");
select * from aeropuerto;
truncate table aeropuerto;

insert into reservaciones values("RSV-435", "10:25","Lunes 28", 4580.00,"V-HK-MX-11");
insert into reservaciones values("RSV-028", "22:35","Lunes 28", 4580.00,"V-HK-MX-11");
insert into reservaciones values("RSV-375", "23:40","Lunes 28", 4580.00,"V-HK-MX-11");
insert into reservaciones values("RSV-019", "00:25","Martes 29", 4580.00,"V-HK-MX-11");
insert into reservaciones values("RSV-001", "01:10","Martes 29", 4580.00,"V-HK-MX-11");
insert into reservaciones values("RSV-945", "02:25","Mier 30", 4580.00,"V-HK-MX-11");
insert into reservaciones values("RSV-366", "03:40","Mier 30", 4580.00,"V-HK-MX-11");
select * from reservaciones;
truncate table reservaciones;

insert into cliente values("josePerez@Gmail.com", "perez21", "José" ,"Perez","León","De la fortuna", 12558, "La feria", 35059, "Gomez", "RSV-435");
insert into cliente values("PerlitaLuna@Gmail.com", "megustalacomidachina", "Perla" ,"Sanchez","Luna","Quinta", 12588, "Los Reyes", 35099, "Torreon", "RSV-028");
insert into cliente values("MariaJose@Gmail.com", "MariJo18", "Mar" ,"Alanis","Vazquez","Octava", 109017, "Refugio", 35047, "Gomez", "RSV-375");
insert into cliente values("CarlosVazquez@Gmail.com", "Hanna21", "Carlos" ,"Vazquez","Aguirre","De la ruleta", 12566, "La feria", 35049, "Gomez", "RSV-019");
insert into cliente values("Pinky_Pie@Gmail.com", "unicornflake", "Luisa" ,"Sanchez","Juarez","Acacia", 89954, "Viñedos", 35099, "Torreon", "RSV-001");
insert into cliente values("DrAlejando_Info@Gmail.com", "VxSAS_w#", "Ramon" ,"De la fuente","Guiterrez","Buenavista", 18123, "Torreon", 35089, "Torreon", "RSV-945");
insert into cliente values("AtomicGirl@Gmail.com", "A_G_902$a", "Estefania" ,"Guzman","Flowers","Chalco", 12575, "San Pedro", 35029, "CDMX", "RSV-366");
Select * from cliente;

insert into tarjeta values(00001345,"Debito","2024-12-01","2019","José","josePerez@Gmail.com");
insert into tarjeta values(00001988,"Debito","2024-11-01","2019","Perla","PerlitaLuna@Gmail.com");
insert into tarjeta values(00008923,"Credito","2022-08-01","2017","Mar","MariaJose@Gmail.com");
insert into tarjeta values(00002948,"Credito","2021-01-01","2018","Carlos","CarlosVazquez@Gmail.com");
insert into tarjeta values(00001102,"Credito","2025-12-01","2020","Luisa","Pinky_Pie@Gmail.com");
insert into tarjeta values(00002258,"Debito","2024-01-01","2021","Ramon","DrAlejando_Info@Gmail.com");
insert into tarjeta values(00004896,"Debito","2023-02-01","2020","Estefania","AtomicGirl@Gmail.com");
select* from tarjeta;

-- Insertando entidades debiles
insert into asiento values("V-HK-MX-11", "Premium", "A21","F21");
insert into asiento values("V-CO-CN-17", "Estandar", "A01","F01");
insert into asiento values("V-CN-CH-19", "Premium", "A31","F03");
insert into asiento values("V-RU-AL-20", "Economico", "A45","F01");
insert into asiento values("V-AL-MX-22", "Estandar", "A32","F03");
insert into asiento values("V-MX-MX-33", "Estandar", "A95","F22");
insert into asiento values("V-CH-RU-78", "Preferente", "A22","F01");
select * from asiento;

insert into tarifa values("V-HK-MX-11", 599.20, "Preferente",.25);
insert into tarifa values("V-CO-CN-17", 998.00, "Preferente",.16);
insert into tarifa values("V-CN-CH-19", 1035.00, "Destacado",.16);
insert into tarifa values("V-RU-AL-20", 442.02, "Normal",.15);
insert into tarifa values("V-AL-MX-22", 325.22, "Normal",.16);
insert into tarifa values("V-MX-MX-33", 895.00, "Preferente",.16);
insert into tarifa values("V-CH-RU-78", 489.00, "Normal",.18);
select * from tarifa;

insert into pago values("RSV-435", "Debito","2019-05-25", 102.00);
insert into pago values("RSV-028", "Credito","2020-02-23", 99.00);
insert into pago values("RSV-375", "Credito","2019-11-09", 35.00);
insert into pago values("RSV-019", "Efectivo","2019-12-23", 20.00);
insert into pago values("RSV-001", "Efectivo","2020-05-10", 1102.00);
insert into pago values("RSV-945", "Credito","2020-03-24", 112.00);
insert into pago values("RSV-366", "Debito","2019-12-03", 52.00);
select * from pago;

insert into avion_vuelo values("AV05","V-HK-MX-11");
insert into avion_vuelo values("AV38","V-CO-CN-17");
insert into avion_vuelo values("AV48","V-CN-CH-19");
insert into avion_vuelo values("AV75","V-RU-AL-20");
insert into avion_vuelo values("AV01","V-AL-MX-22");
insert into avion_vuelo values("AV23","V-MX-MX-33");
insert into avion_vuelo values("AV09","V-CH-RU-78");
select * from avion_vuelo;

insert into vuelo_reservacion values("V-HK-MX-11","RSV-435");
insert into vuelo_reservacion values("V-CO-CN-17","RSV-028");
insert into vuelo_reservacion values("V-CN-CH-19","RSV-375");
insert into vuelo_reservacion values("V-RU-AL-20","RSV-019");
insert into vuelo_reservacion values("V-AL-MX-22","RSV-001");
insert into vuelo_reservacion values("V-MX-MX-33","RSV-945");
insert into vuelo_reservacion values("V-CH-RU-78","RSV-366");
select * from vuelo_reservacion;

insert into cliente_reservacion values("josePerez@Gmail.com","RSV-435");
insert into cliente_reservacion values("PerlitaLuna@Gmail.com","RSV-028");
insert into cliente_reservacion values("MariaJose@Gmail.com","RSV-375");
insert into cliente_reservacion values("CarlosVazquez@Gmail.com","RSV-019");
insert into cliente_reservacion values("Pinky_Pie@Gmail.com","RSV-001");
insert into cliente_reservacion values("DrAlejando_Info@Gmail.com","RSV-945");
insert into cliente_reservacion values("AtomicGirl@Gmail.com","RSV-366");
select * from cliente_reservacion;

insert into pago_tarjeta values(00001345);
insert into pago_tarjeta values(00001988);
insert into pago_tarjeta values(00008923);
insert into pago_tarjeta values(00002948);
insert into pago_tarjeta values(00001102);
insert into pago_tarjeta values(00002258);
insert into pago_tarjeta values(00004896);
select * from pago_tarjeta;

insert into cliente_telefono values("josePerez@Gmail.com","871255885215");
insert into cliente_telefono values("PerlitaLuna@Gmail.com","871415268547");
insert into cliente_telefono values("MariaJose@Gmail.com","871258869587");
insert into cliente_telefono values("CarlosVazquez@Gmail.com","871255698685");
insert into cliente_telefono values("Pinky_Pie@Gmail.com","871236359575");
insert into cliente_telefono values("DrAlejando_Info@Gmail.com","871258556978");
insert into cliente_telefono values("AtomicGirl@Gmail.com","878159658554");
select * from cliente_telefono;

select*from vuelo_reservacion;
select*from cliente_reservacion;
select*from pago_tarjeta;
select*from cliente_telefono;