/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apparbolbinariodebusqueda;

/**
 *
 * @author ivan
 */
public class AppArbolBinarioDeBusqueda {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int []vec = {72,35,96,29,88,122,58,101,16,43,137,55};
        
        ArbolBinarioDeBusqueda arbol = new ArbolBinarioDeBusqueda();
        
        System.out.println("INSERTANDO DATOS EN EL ARBOL");
        
        for(int i = 0; i < vec.length; i++)
        {
            arbol.insertar(vec[i]);
        }
        
        arbol.RecInorden();
    }
    
}
