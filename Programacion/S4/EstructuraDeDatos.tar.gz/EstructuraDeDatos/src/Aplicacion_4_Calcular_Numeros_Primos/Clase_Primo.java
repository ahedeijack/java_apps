/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aplicacion_4_Calcular_Numeros_Primos;

/**
 *
 * @author ahedeijack
 */
public class Clase_Primo {
    
}
