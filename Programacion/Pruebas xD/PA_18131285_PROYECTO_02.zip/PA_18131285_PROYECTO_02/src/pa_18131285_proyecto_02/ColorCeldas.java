/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa_18131285_proyecto_02;

import java.awt.Color;
import javax.swing.JTable;

/**
 *
 * @author gamer
 */
class ColorCeldas {

    public ColorCeldas(JTable jTable1) {
    }

    void addCelda(int r, int i, Color yellow) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
