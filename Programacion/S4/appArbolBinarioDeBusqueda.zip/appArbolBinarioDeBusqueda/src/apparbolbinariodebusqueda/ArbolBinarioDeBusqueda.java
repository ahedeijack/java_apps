/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apparbolbinariodebusqueda;

/**
 *
 * @author ivan
 */
public class ArbolBinarioDeBusqueda {
    
    private class nodoArbol
    {
        private int dato; //string descripcion; double precio; int cantidad; podrian formar cada nodo del arbol
        private ArbolBinarioDeBusqueda der;
        private ArbolBinarioDeBusqueda izq;
        
        private void nodoArbol()
        {
            dato = 0;
            der = null;
            izq = null;
        }
    }
        
        nodoArbol raiz;
        
        public void ArbolBinarioDeBusqueda()
        {
            raiz = new nodoArbol();
        }
        public boolean estaVacio()
        {
            return raiz == null;
        }
        
        public void insertar(int valor)
        {
            if(estaVacio())
            {
                nodoArbol nuevo = new nodoArbol();
                nuevo.dato = valor;
                nuevo.der = new ArbolBinarioDeBusqueda();
                nuevo.izq = new ArbolBinarioDeBusqueda();
                raiz = nuevo;
            }
            else
            {
                if(valor > raiz.dato)
                {
                    raiz.der.insertar(valor);
                }
                if(valor < raiz.dato)
                {
                    raiz.izq.insertar(valor);
                }
            }
        }
        
        public void RecInorden()
        {
            if(!estaVacio()) // != null
            {
                raiz.izq.RecInorden();
                System.out.print(raiz.dato + " , ");
                raiz.der.RecInorden();
            }
        }
    
    
}
