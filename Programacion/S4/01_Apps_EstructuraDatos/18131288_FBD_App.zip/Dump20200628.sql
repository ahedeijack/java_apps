-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: agencia
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aerolinea`
--

DROP TABLE IF EXISTS `aerolinea`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aerolinea` (
  `linea` varchar(5) NOT NULL,
  `nombreAero` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`linea`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aerolinea`
--

LOCK TABLES `aerolinea` WRITE;
/*!40000 ALTER TABLE `aerolinea` DISABLE KEYS */;
INSERT INTO `aerolinea` VALUES ('3','VivaVuelos'),('4','Qatar Airways'),('43','An All Japan'),('5','EVA air'),('6','Qatar AL'),('66','HOLA'),('70','Aerofree'),('72','Aeromexico'),('76','Less Earth');
/*!40000 ALTER TABLE `aerolinea` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aeropuerto`
--

DROP TABLE IF EXISTS `aeropuerto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aeropuerto` (
  `claveAero` varchar(10) NOT NULL,
  `nombAero` varchar(10) DEFAULT NULL,
  `cdAero` varchar(25) DEFAULT NULL,
  `paisAero` varchar(20) DEFAULT NULL,
  `numAero` int DEFAULT NULL,
  `colAero` varchar(10) DEFAULT NULL,
  `cpAero` int DEFAULT NULL,
  `claveAvion` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`claveAero`),
  KEY `claveAvion` (`claveAvion`),
  CONSTRAINT `aeropuerto_ibfk_1` FOREIGN KEY (`claveAvion`) REFERENCES `avion` (`claveAvion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aeropuerto`
--

LOCK TABLES `aeropuerto` WRITE;
/*!40000 ALTER TABLE `aeropuerto` DISABLE KEYS */;
INSERT INTO `aeropuerto` VALUES ('AP-33','AIRLINES','OKLAHOMA','USS',78,'Roswell',66936,'AV01'),('AP-48','KITTYAL','PEKIN','CHINA',16,'WUHAN',48336,'AV09'),('AP-70','MexSky','Santiago','RUSIA',15,'Roswell',2,'AV-15'),('AP-75','DEUSTAIRS','BERLIN','ALEMANIA',5,'SAN PETTER',98851,'AV48'),('AP-82','XHIN AL','BEIJING','CHINA',23,'XHUAN',79458,'AV38'),('AP-91','Prueba Mod','MICHIGAN','USS',19,'St. Panch',55606,'AV75'),('AP-AD','Prueba Add','CDMX','Mexico',22,'Chalco',39099,'AV01');
/*!40000 ALTER TABLE `aeropuerto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asiento`
--

DROP TABLE IF EXISTS `asiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asiento` (
  `claveVue` varchar(10) NOT NULL,
  `categoria` varchar(10) DEFAULT NULL,
  `letra_numero` varchar(10) DEFAULT NULL,
  `fila` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`claveVue`),
  CONSTRAINT `asiento_ibfk_1` FOREIGN KEY (`claveVue`) REFERENCES `vuelo` (`claveVue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asiento`
--

LOCK TABLES `asiento` WRITE;
/*!40000 ALTER TABLE `asiento` DISABLE KEYS */;
INSERT INTO `asiento` VALUES ('V-CH-RU-78','Preferente','A22','F01'),('V-HK-MX-11','Premium','A21','F21'),('V-MX-MX-33','Estandar','A95','F22'),('V-RU-AL-20','Economico','A45','F01');
/*!40000 ALTER TABLE `asiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avion`
--

DROP TABLE IF EXISTS `avion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avion` (
  `claveAvion` varchar(5) NOT NULL,
  `tipoAvion` varchar(25) DEFAULT NULL,
  `numPasajeros` int DEFAULT NULL,
  `nombreCia` varchar(25) DEFAULT NULL,
  `linea` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`claveAvion`),
  KEY `linea` (`linea`),
  CONSTRAINT `avion_ibfk_1` FOREIGN KEY (`linea`) REFERENCES `aerolinea` (`linea`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avion`
--

LOCK TABLES `avion` WRITE;
/*!40000 ALTER TABLE `avion` DISABLE KEYS */;
INSERT INTO `avion` VALUES ('AV23','PruebaM',6,'Mod','1'),('AV48','Boeing 747',200,'TRIVAGO','3'),('AV561','Jet Fx',49,'Oriental Fly','29'),('AV75','COMERCIAL',90,'Qatar Airlines','4'),('AV99','JET FX',5,'NEW','6');
/*!40000 ALTER TABLE `avion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avion_vuelo`
--

DROP TABLE IF EXISTS `avion_vuelo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avion_vuelo` (
  `claveAvion` varchar(5) NOT NULL,
  `claveVue` varchar(10) NOT NULL,
  PRIMARY KEY (`claveAvion`,`claveVue`),
  KEY `claveVue` (`claveVue`),
  CONSTRAINT `avion_vuelo_ibfk_1` FOREIGN KEY (`claveAvion`) REFERENCES `avion` (`claveAvion`),
  CONSTRAINT `avion_vuelo_ibfk_2` FOREIGN KEY (`claveVue`) REFERENCES `vuelo` (`claveVue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avion_vuelo`
--

LOCK TABLES `avion_vuelo` WRITE;
/*!40000 ALTER TABLE `avion_vuelo` DISABLE KEYS */;
INSERT INTO `avion_vuelo` VALUES ('AV01','V-AL-MX-22'),('AV09','V-CH-RU-78'),('AV48','V-CN-CH-19'),('AV38','V-CO-CN-17'),('AV05','V-HK-MX-11'),('AV75','V-RU-AL-20');
/*!40000 ALTER TABLE `avion_vuelo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `emailCte` varchar(35) NOT NULL,
  `contraseña` varchar(20) DEFAULT NULL,
  `nombreCte` varchar(25) DEFAULT NULL,
  `apPatCte` varchar(25) DEFAULT NULL,
  `apMatCte` varchar(25) DEFAULT NULL,
  `calleCte` varchar(35) DEFAULT NULL,
  `numCte` int DEFAULT NULL,
  `colCte` varchar(25) DEFAULT NULL,
  `cpCte` int DEFAULT NULL,
  `cdCte` varchar(25) DEFAULT NULL,
  `claveRes` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`emailCte`),
  KEY `claveRes` (`claveRes`),
  CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`claveRes`) REFERENCES `reservaciones` (`claveRes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES ('AddCliente@','Esto','Añadir','Cliente','De','Prueba',1477,'La Feria',35049,'Gomez','RSV-066'),('AtomicGirl@Gmail.com','A_G_902$a','Modifica','Al','Cliente','xD',12575,'Chalco',35049,'CDMX','RSV-366'),('DrAlejando_Info@Gmail.com','VxSAS_w#','Ramon','De la fuente','Guiterrez','Buenavista',18123,'Torreon',35089,'Torreon','RSV-945'),('EstefaniaF@Hotmail.com','638','Artyom','Morales','Perez','La fortuna',3570,'Barrio Viejo',37017,'Torreon','RSV-738100'),('josePerez@Gmail.com','perez21','José','Perez','León','De la fortuna',12558,'La feria',35059,'Gomez','RSV-435'),('MariaJose@Gmail.com','MariJo18','Mar','Alanis','Vazquez','Octava',109017,'Refugio',35047,'Gomez','RSV-375');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente_reservacion`
--

DROP TABLE IF EXISTS `cliente_reservacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente_reservacion` (
  `emailCte` varchar(35) NOT NULL,
  `claveRes` varchar(10) NOT NULL,
  PRIMARY KEY (`emailCte`,`claveRes`),
  KEY `claveRes` (`claveRes`),
  CONSTRAINT `cliente_reservacion_ibfk_1` FOREIGN KEY (`emailCte`) REFERENCES `cliente` (`emailCte`),
  CONSTRAINT `cliente_reservacion_ibfk_2` FOREIGN KEY (`claveRes`) REFERENCES `reservaciones` (`claveRes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente_reservacion`
--

LOCK TABLES `cliente_reservacion` WRITE;
/*!40000 ALTER TABLE `cliente_reservacion` DISABLE KEYS */;
INSERT INTO `cliente_reservacion` VALUES ('AtomicGirl@Gmail.com','RSV-366'),('MariaJose@Gmail.com','RSV-375'),('josePerez@Gmail.com','RSV-435'),('DrAlejando_Info@Gmail.com','RSV-945');
/*!40000 ALTER TABLE `cliente_reservacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente_telefono`
--

DROP TABLE IF EXISTS `cliente_telefono`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente_telefono` (
  `emailCte` varchar(35) NOT NULL,
  `telCte` varchar(12) NOT NULL,
  PRIMARY KEY (`emailCte`,`telCte`),
  CONSTRAINT `cliente_telefono_ibfk_1` FOREIGN KEY (`emailCte`) REFERENCES `cliente` (`emailCte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente_telefono`
--

LOCK TABLES `cliente_telefono` WRITE;
/*!40000 ALTER TABLE `cliente_telefono` DISABLE KEYS */;
INSERT INTO `cliente_telefono` VALUES ('AtomicGirl@Gmail.com','878159658554'),('DrAlejando_Info@Gmail.com','871258556978'),('josePerez@Gmail.com','871255885215'),('MariaJose@Gmail.com','871258869587'),('PerlitaLuna@Gmail.com','871415268547'),('Pinky_Pie@Gmail.com','871236359575');
/*!40000 ALTER TABLE `cliente_telefono` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pago`
--

DROP TABLE IF EXISTS `pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pago` (
  `claveRes` varchar(10) NOT NULL,
  `tipoPago` varchar(25) DEFAULT NULL,
  `fechaPago` date DEFAULT NULL,
  `cargoCosto` double DEFAULT NULL,
  PRIMARY KEY (`claveRes`),
  CONSTRAINT `pago_ibfk_1` FOREIGN KEY (`claveRes`) REFERENCES `reservaciones` (`claveRes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pago`
--

LOCK TABLES `pago` WRITE;
/*!40000 ALTER TABLE `pago` DISABLE KEYS */;
INSERT INTO `pago` VALUES ('RSV-001','Efectivo','2020-05-10',1102),('RSV-019','Efectivo','2019-12-23',20),('RSV-028','Credito','2020-02-23',99),('RSV-366','Debito','2019-12-03',52),('RSV-375','Credito','2019-11-09',35),('RSV-435','Debito','2019-05-25',102),('RSV-945','Credito','2020-03-24',112);
/*!40000 ALTER TABLE `pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pago_tarjeta`
--

DROP TABLE IF EXISTS `pago_tarjeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pago_tarjeta` (
  `numTarjeta` int NOT NULL,
  PRIMARY KEY (`numTarjeta`),
  CONSTRAINT `pago_tarjeta_ibfk_1` FOREIGN KEY (`numTarjeta`) REFERENCES `tarjeta` (`numTarjeta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pago_tarjeta`
--

LOCK TABLES `pago_tarjeta` WRITE;
/*!40000 ALTER TABLE `pago_tarjeta` DISABLE KEYS */;
INSERT INTO `pago_tarjeta` VALUES (1102),(1345),(1988),(2258),(2948),(4896),(8923);
/*!40000 ALTER TABLE `pago_tarjeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservaciones`
--

DROP TABLE IF EXISTS `reservaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservaciones` (
  `claveRes` varchar(10) NOT NULL,
  `horarioV` varchar(10) DEFAULT NULL,
  `fechaV` varchar(10) DEFAULT NULL,
  `costoRes` double DEFAULT NULL,
  `claveVue` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`claveRes`),
  KEY `claveVue` (`claveVue`),
  CONSTRAINT `reservaciones_ibfk_1` FOREIGN KEY (`claveVue`) REFERENCES `vuelo` (`claveVue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservaciones`
--

LOCK TABLES `reservaciones` WRITE;
/*!40000 ALTER TABLE `reservaciones` DISABLE KEYS */;
INSERT INTO `reservaciones` VALUES ('RSV-366','20:20','PruMod',14588,'M-OD-IF-I'),('RSV-375','23:40','Lunes 28',4580,'V-HK-MX-11'),('RSV-435','10:25','Lunes 28',4580,'V-HK-MX-11'),('RSV-882','1:41','2019/9/19',1897,'V-AR-AR-92'),('RSV-945','02:25','Mier 30',4580,'V-HK-MX-11'),('RSV-ADD','20:20','Lunes',1458,'A-DD-PR-U');
/*!40000 ALTER TABLE `reservaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tarifa`
--

DROP TABLE IF EXISTS `tarifa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tarifa` (
  `claveVue` varchar(10) NOT NULL,
  `costo` double DEFAULT NULL,
  `tipoC` varchar(25) DEFAULT NULL,
  `impuestos` double DEFAULT NULL,
  PRIMARY KEY (`claveVue`),
  CONSTRAINT `tarifa_ibfk_1` FOREIGN KEY (`claveVue`) REFERENCES `vuelo` (`claveVue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tarifa`
--

LOCK TABLES `tarifa` WRITE;
/*!40000 ALTER TABLE `tarifa` DISABLE KEYS */;
INSERT INTO `tarifa` VALUES ('V-CH-RU-78',489,'Normal',0.18),('V-HK-MX-11',599.2,'Preferente',0.25),('V-MX-MX-33',895,'Preferente',0.16),('V-RU-AL-20',442.02,'Normal',0.15);
/*!40000 ALTER TABLE `tarifa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tarjeta`
--

DROP TABLE IF EXISTS `tarjeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tarjeta` (
  `numTarjeta` int NOT NULL,
  `tipoTarj` varchar(10) DEFAULT NULL,
  `fechaVenc` date DEFAULT NULL,
  `añoIni` int DEFAULT NULL,
  `nombTitular` varchar(25) DEFAULT NULL,
  `emailCte` varchar(35) DEFAULT NULL,
  PRIMARY KEY (`numTarjeta`),
  KEY `emailCte` (`emailCte`),
  CONSTRAINT `tarjeta_ibfk_1` FOREIGN KEY (`emailCte`) REFERENCES `cliente` (`emailCte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tarjeta`
--

LOCK TABLES `tarjeta` WRITE;
/*!40000 ALTER TABLE `tarjeta` DISABLE KEYS */;
INSERT INTO `tarjeta` VALUES (1102,'Credito','2025-12-01',2020,'Luisa','Pinky_Pie@Gmail.com'),(1345,'Debito','2024-12-01',2019,'José','josePerez@Gmail.com'),(1988,'Debito','2024-11-01',2019,'Perla','PerlitaLuna@Gmail.com'),(2258,'Debito','2024-01-01',2021,'Ramon','DrAlejando_Info@Gmail.com'),(4896,'Debito','2023-02-01',2020,'Estefania','AtomicGirl@Gmail.com'),(8923,'Credito','2022-08-01',2017,'Mar','MariaJose@Gmail.com');
/*!40000 ALTER TABLE `tarjeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vuelo`
--

DROP TABLE IF EXISTS `vuelo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vuelo` (
  `claveVue` varchar(10) NOT NULL,
  `estadoV` varchar(15) DEFAULT NULL,
  `tipoV` varchar(15) DEFAULT NULL,
  `horaD` varchar(10) DEFAULT NULL,
  `diaD` varchar(10) DEFAULT NULL,
  `horaO` varchar(10) DEFAULT NULL,
  `diaO` varchar(10) DEFAULT NULL,
  `claveAvion` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`claveVue`),
  KEY `claveAvion` (`claveAvion`),
  CONSTRAINT `vuelo_ibfk_1` FOREIGN KEY (`claveAvion`) REFERENCES `avion` (`claveAvion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vuelo`
--

LOCK TABLES `vuelo` WRITE;
/*!40000 ALTER TABLE `vuelo` DISABLE KEYS */;
INSERT INTO `vuelo` VALUES ('V-AL-CN-1','En transcurso','Comercial','6:48','Mier','5:0','Sab','AV11'),('V-CO-CN-17','En transcurso','Prueba','10:25','Lunes','8:55','Miercoles','AV099'),('V-CO-CO-21','En espera','Prueba Ad','10:05','Lunes','10:05','Lunes','AVINS'),('V-HK-MX-11','En espera','Comercial','10:20','Lunes 27','02:00','Domingo 26','AV05'),('V-MX-CN-21','En transcurso','Privado','8:53','Dom','10:14','Lunes','AV87'),('V-RU-AL-20','En espera','Prueba Mod','10:15','Mier','11:20','Jue','AVMO');
/*!40000 ALTER TABLE `vuelo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vuelo_reservacion`
--

DROP TABLE IF EXISTS `vuelo_reservacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vuelo_reservacion` (
  `claveVue` varchar(10) NOT NULL,
  `claveRes` varchar(10) NOT NULL,
  PRIMARY KEY (`claveVue`,`claveRes`),
  KEY `claveRes` (`claveRes`),
  CONSTRAINT `vuelo_reservacion_ibfk_1` FOREIGN KEY (`claveVue`) REFERENCES `vuelo` (`claveVue`),
  CONSTRAINT `vuelo_reservacion_ibfk_2` FOREIGN KEY (`claveRes`) REFERENCES `reservaciones` (`claveRes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vuelo_reservacion`
--

LOCK TABLES `vuelo_reservacion` WRITE;
/*!40000 ALTER TABLE `vuelo_reservacion` DISABLE KEYS */;
INSERT INTO `vuelo_reservacion` VALUES ('V-CH-RU-78','RSV-366'),('V-CN-CH-19','RSV-375'),('V-HK-MX-11','RSV-435'),('V-MX-MX-33','RSV-945');
/*!40000 ALTER TABLE `vuelo_reservacion` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-28 18:41:03
